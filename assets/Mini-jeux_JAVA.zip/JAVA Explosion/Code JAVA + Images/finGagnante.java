import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class finGagnante extends JFrame implements ActionListener {
    private JPanel affichage;
    private JLabel imageGagne;
    private JLabel continuer;
    private JButton yes;
    private JButton no;
    private JLabel principalSecondGagnant;
    
    public finGagnante (){
        this.setTitle("IHM - Final");
        this.setLayout(null);
        this.setSize(900,1300);
        this.setLocationRelativeTo(null);
        this.setResizable(false);
        this.setVisible(false);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        // Panneau principal 
        principalSecondGagnant = new JLabel(new ImageIcon ("./Images/pfc/ExplosionImage.jpg"));
        principalSecondGagnant.setLayout(null);
        principalSecondGagnant.setBounds(0,0,900,1300);
        getContentPane().setLayout(new BorderLayout ());
        getContentPane().add(principalSecondGagnant);
        
        affichage = new JPanel();
        affichage.setLayout(null);
        affichage.setBounds(0,0,900,900);
        affichage.setBackground(new Color(156,132,132));
        
        imageGagne= new JLabel(" ");
		imageGagne.setBounds(0,100,900,500);
        imageGagne.setIcon(new ImageIcon("./Images/pfc/Gagne.png"));
        imageGagne.setBounds(200,0,500,500);
        principalSecondGagnant.add(imageGagne);
        
        continuer = new JLabel(new ImageIcon("./Images/pfc/TryAgain.png"));
        continuer.setBounds(00,400,900,200);
		principalSecondGagnant.add(continuer);
        
        no = new JButton("NO");
		no.setBounds(500,600,400,200);
        no.setFont(new Font("Serif", Font.BOLD, 30));
        no.setForeground(Color.WHITE);
		no.setOpaque(false);
		no.setContentAreaFilled(false);
		no.addActionListener(this);
		principalSecondGagnant.add(no);
        
        yes= new JButton("YES");
		yes.setBounds(20,600,400,200);
        yes.setFont(new Font("Serif", Font.BOLD, 30));
        yes.setForeground(Color.WHITE);
		yes.setOpaque(false);
		yes.setContentAreaFilled(false);
		yes.addActionListener(this);
		principalSecondGagnant.add(yes);
        
        this.add(affichage);
        
    }
    public void actionPerformed (ActionEvent e){
        //Quitte le jeu si le joueur veut arrêter
        if (e.getSource()== no) {
            System.exit(0);
		}
        
        //Recommence une partie
        if (e.getSource()== yes) {
			this.setVisible(false);
		}
    }
}
