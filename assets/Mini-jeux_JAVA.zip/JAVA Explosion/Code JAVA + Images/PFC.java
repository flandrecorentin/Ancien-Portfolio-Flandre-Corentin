import java.util.Scanner;
public class PFC {
	
	public static void main (String[] args) {
		regle presentation = new regle();	
		}
}
