import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class finPerdantMorpion extends JFrame implements ActionListener {
    private JLabel principalSecondPerdant;
    private JPanel affichage;
	private JLabel Perdu;
	private JLabel rejouerPerdu;
    private JButton yes;
    private JButton no;
    
    public finPerdantMorpion (){
        this.setTitle("IHM - Final2");
        this.setLayout(null);
        this.setSize(800,850);
        this.setLocation(960,90);
        this.setResizable(false);
        this.setVisible(false);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        // Panneau principal 
        principalSecondPerdant = new JLabel(new ImageIcon ("./Images/morpion/FlammeFeu.jpg"));
        principalSecondPerdant.setLayout(null);
        principalSecondPerdant.setBounds(0,0,800,850);
        getContentPane().setLayout(new BorderLayout ());
        getContentPane().add(principalSecondPerdant);
        
        affichage = new JPanel();
        affichage.setLayout(null);
        affichage.setBounds(0,0,800,850);

		Perdu= new JLabel(" YOU LOSE ");
		Perdu.setBounds(200,0,800,500);
		Perdu.setForeground(Color.WHITE);
		Perdu.setFont(new Font("Serif", Font.BOLD, 70));
        principalSecondPerdant.add(Perdu);

        rejouerPerdu= new JLabel(" Try Again ? ");
		rejouerPerdu.setBounds(300,200,800,500);
		rejouerPerdu.setForeground(Color.WHITE);
		rejouerPerdu.setFont(new Font("Serif", Font.BOLD, 40));
        principalSecondPerdant.add(rejouerPerdu);
        
        no = new JButton("NO");
		no.setBounds(400,600,400,200);
        no.setFont(new Font("Serif", Font.BOLD, 30));
        no.setForeground(Color.WHITE);
		no.setOpaque(false);
		no.setContentAreaFilled(false);
		no.addActionListener(this);
		principalSecondPerdant.add(no);
        
        yes= new JButton("YES");
		yes.setBounds(0,600,400,200);
        yes.setFont(new Font("Serif", Font.BOLD, 30));
        yes.setForeground(Color.WHITE);
		yes.setOpaque(false);
		yes.setContentAreaFilled(false);
		yes.addActionListener(this);
		principalSecondPerdant.add(yes);
        
        this.add(affichage);
        
    }
    public void actionPerformed (ActionEvent e){
        //Quitte le jeu si le joueur veut arrêter
        if (e.getSource()== no) {
            System.exit(0);
		}
        
        //Recommence une partie
        if (e.getSource()== yes) {
			this.setVisible(false);
		}
    }
}
