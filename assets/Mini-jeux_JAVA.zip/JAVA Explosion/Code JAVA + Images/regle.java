import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class regle extends JFrame implements ActionListener {
    
    private JPanel principal;
	private JLabel titre;
    private JLabel regleJeu;
    private JButton jouer;
	
	public regle (){
        this.setTitle("Regle du jeu");
		this.setSize(900,900);
		this.setLocationRelativeTo(null);
		this.setResizable(false);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        //Panneau principal 
        principal = new JPanel();
        principal.setLayout(null);
        principal.setBounds(0,0,900,900);
        principal.setBackground(Color.WHITE);
        
        titre = new JLabel("");
        titre.setText("Pierre Feuille Ciseaux 2.0");
		titre.setFont(new Font("Serif", Font.BOLD, 60));
		titre.setBounds(125, 50, 900, 70);
		titre.setForeground(Color.BLACK);
		principal.add(titre);
        
        //Affichage des règles du jeu
        regleJeu= new JLabel("");
        regleJeu.setText("<html> Ce mini-jeu est un pierre feuille ciseaux 2.0. En effet, la pierre est remplacee par une boule de feu, la feuille par un bouclier et le ciseaux par un laser. Ainsi :<br>"
                + " - La boule de feu gagne contre le laser <br>"
                + " - Le laser gagne contre le bouclier <br>"
                + " - Le bouclier gagne contre la boule de feu <br>"
                + "   <br>"
                + " Une manche est gagne si un des 2 joueurs fait une attaque qui 'tue' l'adversaire. Une partie de deroule au meilleur des 3 manches. <br>"
                + "   <br>"
                + " Ce jeu requiert vigilence et precision pour sortir vainqueuer de la bataille contre l'ordinateur. </html>");
           
		regleJeu.setBounds(10,150,900,400);
		regleJeu.setFont(new Font("Serif", Font.BOLD, 20));
		principal.add(regleJeu);
        
        //Création du bouton lancement du jeu
        jouer = new JButton("JOUER");
		jouer.setBounds(350,700,200,100);
        jouer.setFont(new Font("Serif", Font.BOLD, 30));
        jouer.setForeground(Color.BLACK);
		jouer.setOpaque(false);
		jouer.setContentAreaFilled(false);
		jouer.addActionListener(this);
		principal.add(jouer);
        
        this.add(principal);
        this.setVisible(true);
    }
    
    //Lancement du jeu
    public void actionPerformed (ActionEvent e){
        if (e.getSource()== jouer){
            this.setVisible(false);
            GraphiquePFC presentation = new GraphiquePFC();	
        }
    }
}
