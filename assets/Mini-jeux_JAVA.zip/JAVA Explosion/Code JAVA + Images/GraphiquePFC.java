import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class GraphiquePFC extends JFrame implements ActionListener {
    //appel des classes et variables utiles
	private Explosion explosion;
    private finGagnante affichageFinalGagne;
    private finPerdante affichageFinalPerdu;
	private int numManche;
	private int gagnant;
    
    //creation fenêtre
    private JLabel principalSecond;
    private JLabel titre;
    private JLabel nom;
    private JTextField nomJoueur;
    private JLabel manche;
    private JLabel ordinateur;
    private JLabel choixOrdi; 
    
    private JLabel choixJoueur;
    private JButton boutonBdF;
	private JButton boutonBouclier;
	private JButton boutonLaser;
    
    private JLabel resultatPartie;
    private JLabel resultat1;
	private JLabel resultat2;
    
    private JPanel principal;
	private JTextArea afficher;
	
	public GraphiquePFC (){
		explosion = new Explosion();
        affichageFinalGagne = new finGagnante();
        affichageFinalPerdu = new finPerdante();
		this.setTitle("Attaque Surprise");
		this.setSize(900,1300);
		this.setLocationRelativeTo(null);
		this.setResizable(false);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        numManche= 1;
        gagnant = 0;
        
        // creation widgets
        principalSecond = new JLabel(new ImageIcon ("./Images/pfc/ExplosionImage.jpg"));
        principalSecond.setLayout(null);
        principalSecond.setBounds(0,0,900,1300);
        getContentPane().setLayout(new BorderLayout ());
        getContentPane().add(principalSecond);
                
        titre = new JLabel();
		titre.setText("Pierre-Feuille-Ciseaux 2.0");
		titre.setFont(new Font("Serif", Font.BOLD, 60));
		titre.setBounds(100, 20, 700, 70);
		titre.setForeground(Color.BLACK);
		principalSecond.add(titre);
        
        nom= new JLabel("Entrez votre nom : ");
		nom.setBounds(150,100,450,100);
		nom.setFont(new Font("Serif", Font.BOLD, 20));
		nom.setForeground(Color.BLACK);
		principalSecond.add(nom);
        
        nomJoueur = new JTextField();
		nomJoueur.setBounds(350, 130, 200, 50);
		nomJoueur.setFont(new Font("Contour", Font.BOLD, 30));
		nomJoueur.setBackground(Color.BLACK);
		nomJoueur.setForeground(Color.WHITE);
		principalSecond.add(nomJoueur);
        
        manche = new JLabel("Partie numero : " + numManche);
        manche.setBounds(650,130,450,50);
		manche.setFont(new Font("Serif", Font.BOLD, 20));
		manche.setForeground(Color.BLACK);
		principalSecond.add(manche);
        
        ordinateur = new JLabel();
		ordinateur.setText("Choix de l'ordinateur : ");
		ordinateur.setFont(new Font("Serif", Font.BOLD, 20));
		ordinateur.setBounds(10, 250, 200, 50);
		principalSecond.add(ordinateur);
        
		choixOrdi= new JLabel(" ");
		choixOrdi.setBounds(500,300,300,200);
		principalSecond.add(choixOrdi);
        
		choixJoueur= new JLabel("Cliquer sur une image pour chosir votre attaque : ");
		choixJoueur.setBounds(10,350,750,100);
		choixJoueur.setFont(new Font("Serif", Font.BOLD, 30));
		principalSecond.add(choixJoueur);
        
		boutonBdF = new JButton(new ImageIcon("./Images/pfc/BouleDeFeu.png"));
		boutonBdF.setBounds(100, 600, 150, 150);
		boutonBdF.setOpaque(false);
		boutonBdF.setContentAreaFilled(false);
		boutonBdF.addActionListener(this);
		principalSecond.add(boutonBdF);
		
		boutonBouclier = new JButton(new ImageIcon("./Images/pfc/Bouclier.png"));
		boutonBouclier.setBounds(375, 450, 150, 165);
		boutonBouclier.setFont(new Font("Serif", Font.BOLD, 20));
		boutonBouclier.setOpaque(false);
		boutonBouclier.setContentAreaFilled(false);
		boutonBouclier.addActionListener(this);
		principalSecond.add(boutonBouclier);
		
		boutonLaser = new JButton(new ImageIcon("./Images/pfc/Laser.png"));
		boutonLaser.setBounds(645, 630, 150, 125);
		boutonLaser.setFont(new Font("Serif", Font.BOLD, 20));
		boutonLaser.setOpaque(false);
		boutonLaser.setContentAreaFilled(false);
		boutonLaser.addActionListener(this);
		principalSecond.add(boutonLaser);
       
        resultat1= new JLabel(" ");
		resultat1.setBounds(10,850,450,50);
		resultat1.setFont(new Font("Serif", Font.BOLD, 20));
		principalSecond.add(resultat1);
		
		resultat2= new JLabel(" ");
		resultat2.setBounds(10,900,450,50);
		resultat2.setFont(new Font("Serif", Font.BOLD, 20));
		principalSecond.add(resultat2);
		
		resultatPartie= new JLabel(" ");
		resultatPartie.setBounds(10,800,450,50);
		resultatPartie.setFont(new Font("Serif", Font.BOLD, 20));
		principalSecond.add(resultatPartie);
		
		// Conteneur principal
		principal = new JPanel();
        principal.setLayout(null);
        principal.setBounds(0,0,900,1300);
        
        principalSecond.add(principal);
        
		afficher = new JTextArea();
		afficher.setLineWrap(true);
		
        this.add(principal);
		this.setVisible(true);
	}
	
    //méthode pour appuyer sur boutons
	public void actionPerformed (ActionEvent e){
        //Affichage message si le nom n'est pas rentré
        while (nomJoueur.getText().equals("")){
			JOptionPane.showMessageDialog(this, "Ecris ton blaze frerot ! ");
			return;
		}
        
        //choix du laser
        if (e.getSource()== boutonLaser) {
            explosion.setChoix("Laser");
            gagnant = explosion.joue("Laser");
            rafraichirAI(explosion.getscoreJoueur(), explosion.getscoreOrdi());
            numManche = GagnePerdu(numManche);
        }
        
        //choix du bouclier
        if (e.getSource()== boutonBouclier) {
            explosion.setChoix("Bouclier");
            gagnant = explosion.joue("Bouclier");
            rafraichirAI(explosion.getscoreJoueur(), explosion.getscoreOrdi());
            numManche = GagnePerdu(numManche);
        }
        
        //choix de la BDF
        if (e.getSource()== boutonBdF) {
            explosion.setChoix("BouleDeFeu");
            gagnant = explosion.joue("BouleDeFeu");
            rafraichirAI(explosion.getscoreJoueur(), explosion.getscoreOrdi());
            numManche = GagnePerdu(numManche);
        }
        
        //Test de fin de partie
        if (gagnant == 1){
			resultatPartie.setText(nomJoueur.getText() + " gagne cette manche");
		}if (gagnant == -1){
			resultatPartie.setText("L'ordinateur gagne cette manche");
		}if (gagnant == 0){
			resultatPartie.setText("Egalite entre l'ordinateur et " + nomJoueur.getText());
		}
    }
	
    //Affichage du choix de l'ordinateur
	public void rafraichirAI(int scorej1, int scorepc){
		if (explosion.getchoixAI().equals("Laser")){
			choixOrdi.setIcon(new ImageIcon("./Images/pfc/Laser.png"));
			choixOrdi.setBounds(280,220,150,150);
		}else if (explosion.getchoixAI().equals("Bouclier")){
			choixOrdi.setIcon(new ImageIcon("./Images/pfc/Bouclier.png"));
			choixOrdi.setBounds(280,220,150,150);
		}else if (explosion.getchoixAI().equals("BouleDeFeu")){
			choixOrdi.setIcon(new ImageIcon("./Images/pfc/BouleDeFeu.png"));
			choixOrdi.setBounds(280,220,150,150);
		}
		resultat2.setText("Le score de l'ordinateur est de : " + scorepc);
		resultat1.setText("Votre score est de : " + scorej1);
	}
	
    //Affichage du résultat de chaque manche dans une partie 
	public int GagnePerdu(int r){
		if (explosion.getGagne()==1){
            affichageFinalGagne.setVisible(true);
            explosion.rejouer();
            r+=1;
            manche.setText("Partie numero : " + r);
        }
        if (explosion.getGagne()==2 ){
            affichageFinalPerdu.setVisible(true);
            explosion.rejouer();
            r+=1;
            manche.setText("Partie numero : " + r);
        }
        return r;
    }
}


