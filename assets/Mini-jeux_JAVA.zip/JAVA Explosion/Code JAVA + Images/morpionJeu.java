import java.util.Scanner;
public class morpionJeu {
	
	public static void main (String[] args) {
        fenetre jeu = new fenetre();
	}

}
