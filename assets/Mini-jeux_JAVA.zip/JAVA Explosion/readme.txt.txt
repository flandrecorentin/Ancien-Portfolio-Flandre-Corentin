Pour consulter la video présentation de notre projet, voici le lien:

https://youtu.be/Yyx4H5PQCQA

Contenu du dossier:

-Dossier "Code JAVA + Images"
-PDF "Rapport_CALBA_FLANDRE_PLANCHON_VARELAD-COULAUD"
-fichier texte "readme.txt"

Le code JAVA permettant de faire fonctionner les différents mini-jeux 
est dans le dossier "Code JAVA + Images". La classe à éxecuter est 
la classe nommé "Jeu" et à partir de la fenetre principal il faut choisir
le mini jeu auquel on souhaite jouer à l'aide des boutons. 

Le rapport sous format PDF contient notamment le cahier des charges
du projet d'informatique et les diagrammes UML de certains mini-jeux. 



REMARQUE pour certains mini-jeux: 


Projet réalisé par
CALBA Lise, FLANDRE Corentin, PLANCHON Léa, VARELA-COULAUD Léanne