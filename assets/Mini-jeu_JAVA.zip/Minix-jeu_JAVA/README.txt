*******************************************************************************
Cette archive "Mini-jeu_Java" concerne une plateforme de mini-jeux codés 
purement en JAVA. Pour pouvoir jouer il faut avoir de quoi compilater un 
programme java sur son PC, ainsi qu'un jdk (Java Development Kit) assez récent.
Le fichier a executer est le fichier Jeu.java avec la commande: 
java Jeu
Si vous n'arrivez pas à ouvrir le Jeu ou que vous voulez des informations 
supplémentaires, contactez-moi (flandrecorentin@gmail.com).
Cette plateforme de jeu a été créé durant ma 1° année d'école d'ingénieur.  
*******************************************************************************