cd JAVA_Code/
java Jeu